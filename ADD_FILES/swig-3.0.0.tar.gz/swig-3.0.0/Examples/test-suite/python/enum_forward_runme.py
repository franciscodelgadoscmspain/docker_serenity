import enum_forward
  
f1 = enum_forward.get_enum1();
f1 = enum_forward.test_function1(f1);

f2 = enum_forward.get_enum2();
f2 = enum_forward.test_function2(f2);

f3 = enum_forward.get_enum3();
f3 = enum_forward.test_function3(f3);
